<template>
  <div class="mt-8 flex justify-center items-center dark:text-white">
    <p>iNamaz - reminder for Muslims</p>
  </div>
</template>

<script>
export default {};
</script>
