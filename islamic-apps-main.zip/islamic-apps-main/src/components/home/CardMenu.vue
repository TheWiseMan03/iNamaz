<template>
  <div
    class="bg-gradient-to-r from-emerald-700 to-teal-500 rounded-md p-3 sm:p-1"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>