<template>
  <div
    class="px-8 pt-6 pb-4 max-w-xl max-h-full mx-auto bg-[#f7f7f7] dark:bg-slate-900"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
</style>